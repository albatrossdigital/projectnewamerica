<center>
<table cellpadding="0" cellspacing="0" width="750" style="border: 1px solid #dddddd;font-size: .9em;font-family: Arial, Helvetica, sans-serif;color: #444444;">
<tbody>
<tr><td><img style="border-bottom: 5px solid #19537B;" src="http://advocate.nyc.gov/files/public_advocate_e-newsletter_header.png" alt="Bill de Blasio: Public Advocate for the City of New York" height="100" width="750"></td></tr><tr><td style="padding:5px;">

<?php print $body; ?>

</td></tr><tr><td style="color: #888888; padding-top: 5px; border-top: 1px solid #eeeeee;text-align:center;">
<p>[unsubscribe]</p>
<p><div class="location vcard"><span class="adr"><span class="street-address">1 Centre Street, 15th Floor</span><br /><span class="locality">New York</span>, <span class="region">NY</span> <span class="postal-code">10007</span><br /><span class="country-name">United States</span></span></div><br/><a href='http://advocate.nyc.gov/sites/all/modules/civicrm/extern/url.php?u=190&qid=175861'>www.advocate.nyc.gov</a></p>

</td>
</tr>
</tbody>
</table>
</center>

