<?php print $text_message; ?>

------
[unsubscribe]
03 East 17th Avenue, Suite 320
Denver, CO 80203
