/**
 * Custom JS crm_mailing
 */

/* New D7 Wrapper --> */(function ($) {

Drupal.behaviors.crm_mailing = {
  attach: function(context, settings) { //new attach function
    /*$('#edit-action-item input.form-radio').click(function(){
      switch($(this).val()){
        case 'test_email':
          console.log($('.vertical-tabs-list li:eq(1)').html());
          $('.vertical-tabs-list li').removeClass('selected');
        break;
        case 'schedule':
          
        break;
      }
    });*/

    //alert('a');
  }//attach
};//behaviors

/* New D7 Wrapper --> */ })(jQuery);
