<div class="twitter-pull-block-wrapper">
  <?php if ($links): ?>
    <div class="twitter-pull-block-header clearfix">
      <a href="http://twitter.com/#!/<?php print $id; ?>" class="twitter-follow-link">Follow Us</a>
    </div>
  <?php endif; ?>
  <div class="twitter-pull-block-content">
    <?php print $content; ?>
  </div>
</div>
