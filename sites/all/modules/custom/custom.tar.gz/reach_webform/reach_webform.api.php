<?php
/**
 * @file
 * This file contains no working PHP code; it exists to provide additional
 * documentation for doxygen as well as to document hooks in the standard
 * Drupal manner.
 */

/**
 * Implementatation of reach_webform_submitted.
 *
 * Save the relation.
 */
function hook_reach_webform_submitted($party, $node, $entity) {

}
