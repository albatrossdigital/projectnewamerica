
(function ($) {

Drupal.behaviors.reach_webform_cookie = {
  attach: function(context, settings) { 
    
    var pid_data = $.parseJSON($.cookie('reach_crm_pid_data'));
    if (pid_data) {
      $('.webform-client-form').each(function(){
        $form = $(this);
        $.each(pid_data, function(index, value){
          $field = $('form input[name*=' + index.replace('field_', '') + ']');
          $($field, $form).val(value.replace(/\+/gi, ' '));
          $field.parents('form.infieldlabels').find('label').hide();
        });
      });
    }
    
  }//attach
};//behaviors

})(jQuery);

