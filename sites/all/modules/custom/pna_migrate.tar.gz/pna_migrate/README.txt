Used for one-time PNA migration routines.

Run ls -C to get list of all files/dirs in a dir and then paste that into the fieldset at admin/pna-migrate
