<?php
  echo drupal_render($form);
?>
